import {Injectable} from '@angular/core';
import {CanActivate,Router} from '@angular/router';
export class User {
    constructor(
      public email: string,
      public password: string) { }
  }
  var users = [
    new User('admin@admin.com','adm9'),
    new User('user1@gmail.com','a23')
  ];
@Injectable()
export class AuthService implements CanActivate{
constructor(private route:Router)
{

}
logout() {
    localStorage.removeItem("user");
    this.route.navigate(['']);
  }
  login(user){
    var authenticatedUser = users.find(u => u.email === user.email);
    if (authenticatedUser && authenticatedUser.password === user.password){
      localStorage.setItem("user", JSON.stringify(authenticatedUser));
      this.route.navigate(['Home']);      
      return true;
    }
    return false;
 
  }
 
   checkCredentials(){
    if (localStorage.getItem("user") === null){
        this.route.navigate(['']);
    }
  } 
    canActivate(){
        if (localStorage.getItem("user") === null){
             this.route.navigate(['/unauthorized']);
        return false;
        }
        else{
            return true;
        }
       
    }
}