import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import{RouterModule,Routes} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import {HomeComponent} from '../app/home/home';
import {LoginComponent} from '../app/login/login.component';
import {routes} from './app.routing';
import{ OrderComponent} from '../app/Order/order.component';
import{NotAuthorisedComponent} from '../app/erropages/unauthorised';
import {AuthService} from '../app/services/auth.service';
@NgModule({
  imports: [ BrowserModule, FormsModule,ReactiveFormsModule,RouterModule.forRoot(routes)
    ,HttpClientModule
],
  declarations: [ AppComponent
    ,OrderComponent,HomeComponent,LoginComponent,NotAuthorisedComponent
],
  bootstrap: [ AppComponent ], 
  providers:[AuthService]
})

export class AppModule {}