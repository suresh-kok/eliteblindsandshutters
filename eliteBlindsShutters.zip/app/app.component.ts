import{Component} from '@angular/core';
import {Router} from '@angular/router';
import {LoginComponent} from '../app/login/login.component';
import {AuthService, User} from '../app/services/auth.service';
@Component({
selector:'my-app',
providers:[AuthService],
templateUrl:'app/Views/appcomponent.html'
})

export class AppComponent{

    constructor(private route:Router,private service:AuthService){

    }
LogOut(){
    
        this.service.logout();
}
}
