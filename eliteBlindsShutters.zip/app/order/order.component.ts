import {Component} from '@angular/core';
import {AuthService, User} from '../../app/services/auth.service';
@Component({
    selector:'place-order',
    templateUrl:'app/order/ordercomponent.html'
})
export class OrderComponent{
    constructor(private service:AuthService){
        
            }
    ngOnInit(){
        this.service.checkCredentials();
    }
}