import {Component} from '@angular/core';
@Component({
    selector:'home',
    templateUrl:'app/home/home.html'
})
export class HomeComponent{}