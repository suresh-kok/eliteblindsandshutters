"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var auth_service_1 = require("../../app/services/auth.service");
var orderdata_1 = require("../DataModels/orderdata");
var OrderComponent = /** @class */ (function () {
    function OrderComponent(service, element) {
        this.service = service;
        this.OrderDetails = [];
        this.enableCheckOut = false;
        this.orderItem = new orderdata_1.OrderData();
        // this.OrderDetails=new OrderData();
    }
    OrderComponent.prototype.ngOnInit = function () {
        this.service.checkCredentials();
    };
    OrderComponent.prototype.AddItem = function () {
        debugger;
        this.OrderDetails.push(this.orderItem);
        this.orderItem = new orderdata_1.OrderData();
    };
    OrderComponent.prototype.OrderConfirm = function () {
        debugger;
        // this.element.nativeElement.querySelector('#extraTab').click();
        var el = this.extra.nativeElement;
        var elDetails = this.details.nativeElement;
        var elHome = this.home.nativeElement;
        el.click();
        elDetails.
            this.enableCheckOut = true;
    };
    OrderComponent.prototype.Delete = function (item) {
        this.OrderDetails.pop(item);
    };
    __decorate([
        core_1.ViewChild('extra'),
        __metadata("design:type", core_1.ElementRef)
    ], OrderComponent.prototype, "extra", void 0);
    __decorate([
        core_1.ViewChild('details'),
        __metadata("design:type", core_1.ElementRef)
    ], OrderComponent.prototype, "details", void 0);
    __decorate([
        core_1.ViewChild('home'),
        __metadata("design:type", core_1.ElementRef)
    ], OrderComponent.prototype, "home", void 0);
    OrderComponent = __decorate([
        core_1.Component({
            selector: 'place-order',
            templateUrl: 'app/order/ordercomponent.html'
        }),
        __metadata("design:paramtypes", [auth_service_1.AuthService, core_1.ElementRef])
    ], OrderComponent);
    return OrderComponent;
}());
exports.OrderComponent = OrderComponent;
//# sourceMappingURL=order.component.js.map