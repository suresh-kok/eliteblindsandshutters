import {Component,ElementRef,ViewChild} from '@angular/core';
import {AuthService, User} from '../../app/services/auth.service';
import {OrderData}from '../DataModels/orderdata';
@Component({
    selector:'place-order',
    templateUrl:'app/order/ordercomponent.html'
})
export class OrderComponent{
    @ViewChild('extra') extra: ElementRef;
    @ViewChild('details') details: ElementRef;
    @ViewChild('home') home: ElementRef;
    orderItem:OrderData;
    OrderDetails:any[]=[];
    enableCheckOut:boolean=false;
    constructor(private service:AuthService,element: ElementRef){
        this.orderItem=new OrderData();
        // this.OrderDetails=new OrderData();
            }
    ngOnInit(){
        this.service.checkCredentials();
    }
    AddItem()
    {
        debugger;
        this.OrderDetails.push(this.orderItem);
        this.orderItem=new OrderData();
    }
    OrderConfirm(){
        debugger;
        // this.element.nativeElement.querySelector('#extraTab').click();
        let el: HTMLElement = this.extra.nativeElement as HTMLElement;
        let elDetails: HTMLElement = this.details.nativeElement as HTMLElement;
        let elHome: HTMLElement = this.home.nativeElement as HTMLElement;
        el.click();
        elDetails.
        this.enableCheckOut=true;
    }
    Delete(item:any)
    {
        this.OrderDetails.pop(item);
    }

}