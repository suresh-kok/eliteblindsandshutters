"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OrderData = /** @class */ (function () {
    function OrderData() {
    }
    return OrderData;
}());
exports.OrderData = OrderData;
//# sourceMappingURL=orderdata.js.map