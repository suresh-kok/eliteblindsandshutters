export class OrderData{
    slatStyle:any;
    cordStyle:any;
    makeWidth:any;
    pelmetWidth:any;
    mount:any;
    returnRequired:any;
    makeHeight:any;
    readyMadeSize:any;
    widthMade:any;
    heightMade:any;
    qualityCheck:any;
    squareMeter:any
}