import {Component} from '@angular/core';
import {AuthService, User} from '../../app/services/auth.service';
@Component({
    selector:'home',
    templateUrl:'app/home/home.html'
})
export class HomeComponent{
    constructor(private service:AuthService){
       
            }
    ngOnInit(){
        this.service.checkCredentials();
    }
}