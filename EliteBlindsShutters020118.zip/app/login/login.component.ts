import {Component} from '@angular/core';
import {Router} from '@angular/router';
import {AuthService, User} from '../../app/services/auth.service';
@Component({
    selector:'login',
    templateUrl:'app/login/login.html',
    styleUrls:['app/login/login.css'],
    // providers:[AuthService]
})
export class LoginComponent{
user:User;
errorMsg:any;
showMsg:boolean=false;
showSignUp:boolean=false;

    constructor(private route:Router,private service:AuthService){
        this.user=new User("","");
            }
    Login()
    {
        if(!this.service.login(this.user)){
            this.errorMsg = 'Failed to login';
            this.showMsg=true;
        }
        
    }
    ShowLogin()
    {
        this.user=new User("","");
        this.showSignUp=false;
    }
    SignUp(){
        this.user=new User("","");
        this.showSignUp=true;
    }
}